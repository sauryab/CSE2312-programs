#include "global.h"

Gui_Window_AppWidgets *gui_app; //structure to keep all interesting widgets

int operand=0;
int last_function=0;
int clear_f;
